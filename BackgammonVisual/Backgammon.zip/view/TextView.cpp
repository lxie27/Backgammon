//
// Created by Rikki on 11/9/2017.
//

#include "TextView.h"
#include <string>

using namespace std;

/**
 * Outputs the current state of the Backgammon game to standard out.
 */
void TextView::refresh() {
    std::cout << this->m_currentState << std::endl;
}

/**
 * Updates the current state of the View.
 * @param state
 */
void TextView::updateState(string state) {
    this->m_currentState = state;
}
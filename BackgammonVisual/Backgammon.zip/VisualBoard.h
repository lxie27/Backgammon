#pragma once
#include "Game.h"
#include "GameObject.h"

class VisualBoard {
public:
	VisualBoard();
	~VisualBoard();

	// creates the initial board state by copying initialBoardLayout into pieceLayout
	void LoadBoard(int arr[2][17]);

	// draws the graphics given by pieceLayout onto the board
	void DrawBoard();

	// draws the board after a move is made
	void PieceMove(int startingRow, int startingColumn, int destinationRow, int destinationColumn);

	// adds the rolled dice values into the dice to determine what graphic they show
	void diceRoll(int diceRoll1, int diceRoll2);

	// adds a point to cubePowerCount when a player uses it in the game
	void doublingCubeIncrease();

	// takes in the positions of the indicators, as well as how many possibilites there are,
	// and maps that info to the indicatorPositions array, which is used by DrawBoard
	// to place each indicator on the board
	void possibleIndicators(int positions[4][2], int possibilites);

	// sets the doubling cube value back to a given int
	// used by TextController to reset the doublingCube when
	// a forfeit by denying the proposal occurs
	void setDoublingCube(int value);

	// outputs a string of what color the pieces in the given row and column are
	const char * pieceValue(int row, int column);

	// checks if there is currently one piece of a space, either one black or white piece
	// used by TextController to confirm a piece is being captured by a move so the visuals
	// can be drawn accordingly (captured piece sent to middle of board, capturing piece replacing it in space)
	bool checkSpace(int row, int column);

private:

	// the dimensions for the source graphics and their destination on the board
	SDL_Rect src, dest;

	// textures for all the game pieces that will be used
	SDL_Texture* white_piece;
	SDL_Texture* black_piece;
	SDL_Texture* captured_white_piece; // visual of pieces in final capture slot
	SDL_Texture* captured_black_piece;
	SDL_Texture* possible_indicator;
	SDL_Texture* possible_indicator_upside_down; // a flipped image of the possible_indicator for the bottom half of the board
	SDL_Texture* doubling_cube;
	SDL_Texture* die1;
	SDL_Texture* die2;
	SDL_Texture* die3; // the two double die
	SDL_Texture* die4;

	// the array that is given the information on where the pieces are
	int pieceLayout[2][17];
};

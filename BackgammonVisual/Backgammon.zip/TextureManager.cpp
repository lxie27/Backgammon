#include "TextureManager.h"
#include "../BackgammonVisuals/controller/TextController.h"

SDL_Texture* TextureManager::LoadTexture(const char* fileName)
{
	SDL_Surface* tempSurface = IMG_Load(fileName);
	SDL_Texture* tempTex = SDL_CreateTextureFromSurface(TextController::renderer, tempSurface);
	SDL_FreeSurface(tempSurface); // so it can be reused next time

	return tempTex;
}

void TextureManager::Draw(SDL_Texture* text, SDL_Rect src, SDL_Rect dest)
{
	SDL_RenderCopy(TextController::renderer, text, &src, &dest);
}
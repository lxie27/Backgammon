#include <iostream>
#include "../model/BackgammonModel.h"
#include "../controller/TextController.h"
#include <ctime>
#include <memory>
#include "SDL.h"
#undef main
#include "SDL_image.h"
#include "../game.h"

using namespace std;

Game *game = nullptr;

int main() {
	
    srand(time(NULL));
    BackgammonModel * model = new BackgammonModel();
    model->startGame();

    Player p1 = model->getPlayer1();
    Player p2 = model->getPlayer2();
	
	// outputting player names, colors and scores
    p1.output();
    cout << endl;
    p2.output();
    cout << endl;

    TextView view = TextView();
    shared_ptr<TextController> controller(new TextController(view, model));
	controller->go();

	/* // ERIC'S

	// setting frame rate
	const int FPS = 60;
	const int frameDelay = 1000 / FPS;

	Uint32 frameStart;
	int frameTime;

	game = new Game();

	game->init("Backgammon", SDL_WINDOWPOS_UNDEFINED, SDL_WINDOWPOS_UNDEFINED, 1280, 720, false);

	while (game->running()) {

		frameStart = SDL_GetTicks();

		game->handleEvents(); // handle events
		game->render(); // render changes to display

		frameTime = SDL_GetTicks() - frameStart;

		if (frameDelay > frameTime)
		{
			SDL_Delay(frameDelay - frameTime);
		}
	}

	game->clean();

	// BACK */


    controller->go();

    delete model;

	/*
	// setting frame rate
	const int FPS = 60;
	const int frameDelay = 1000 / FPS;

	Uint32 frameStart;
	int frameTime;

	game = new Game();

	game->init("Backgammon", SDL_WINDOWPOS_UNDEFINED, SDL_WINDOWPOS_UNDEFINED, 1280, 720, false);

	while (game->running()) {

		frameStart = SDL_GetTicks();

		game->handleEvents(); // handle events
		game->update(); // update all object positions etc.
		game->render(); // render changes to display

		frameTime = SDL_GetTicks() - frameStart;

		if (frameDelay > frameTime)
		{
			SDL_Delay(frameDelay - frameTime);
		}
	}

	game->clean();

	/*
	bool quit = false;
	SDL_Event event;

	SDL_Init(SDL_INIT_VIDEO);
	IMG_Init(IMG_INIT_JPG);

	SDL_Window * window = SDL_CreateWindow("SDL2 Displaying Image",
	SDL_WINDOWPOS_UNDEFINED, SDL_WINDOWPOS_UNDEFINED, 1280, 720, 0);

	SDL_Renderer * renderer = SDL_CreateRenderer(window, -1, 0);
	SDL_Surface * image = IMG_Load("Graphics/backgammon_board.png");
	SDL_Texture * texture = SDL_CreateTextureFromSurface(renderer, image);

	while (!quit)
	{
	SDL_WaitEvent(&event);

	switch (event.type)
	{
	case SDL_QUIT:
	quit = true;
	break;
	}

	//SDL_Rect dstrect = { 5, 5, 320, 240 };
	//SDL_RenderCopy(renderer, texture, NULL, &dstrect);
	SDL_RenderCopy(renderer, texture, NULL, NULL);
	SDL_RenderPresent(renderer);
	}

	SDL_DestroyTexture(texture);
	SDL_FreeSurface(image);
	SDL_DestroyRenderer(renderer);
	SDL_DestroyWindow(window);

	IMG_Quit();
	SDL_Quit();
	*/

	
	/*
	SDL_Init(SDL_INIT_EVERYTHING);
	SDL_Window *window = SDL_CreateWindow("Backgammon", SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED, 600, 400, SDL_WINDOW_SHOWN);
	SDL_Renderer *renderer = SDL_CreateRenderer(window, -1, 0);

	SDL_SetRenderDrawColor(renderer, 0, 255, 0, 255);

	SDL_RenderClear(renderer);

	SDL_RenderPresent(renderer);

	SDL_Delay(3000);

	return 0;*/

    return 0;
}
//
// Created by Leslie on 11/7/2017.
//

#ifndef BACKGAMMON_COLOR_HPP
#define BACKGAMMON_COLOR_HPP

enum Color{BLACK, WHITE, EMPTY};

#endif //BACKGAMMON_COLOR_HPP

#include "GameObject.h"
#include "TextureManager.h"
#include "../BackgammonVisuals/controller/TextController.h"

GameObject::GameObject(const char* textureSheet, int x, int y)
{
	objTexture = TextureManager::LoadTexture(textureSheet);

	xpos = x;
	ypos = y;
}

GameObject::~GameObject() {}

void GameObject::Update()
{
	xpos++;
	ypos++;

	srcRect.h = 64;
	srcRect.w = 64;
	srcRect.x = 0;
	srcRect.y = 0;

	destRect.h = srcRect.h;
	destRect.w = srcRect.w;
	destRect.x = xpos;
	destRect.y = ypos;
}

void GameObject::BoardRender()
{
	SDL_RenderCopy(TextController::renderer, objTexture, NULL, NULL);
}

void GameObject::Render()
{
	SDL_RenderCopy(TextController::renderer, objTexture, NULL, &destRect);
}
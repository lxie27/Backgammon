//
// Created by Rikki on 11/9/2017.
//

#ifndef BACKGAMMON_ICONTROLLER_H
#define BACKGAMMON_ICONTROLLER_H

class IController {
public:
    virtual void go() =0;
};

#endif //BACKGAMMON_ICONTROLLER_H

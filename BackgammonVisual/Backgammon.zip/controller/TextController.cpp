//
// Created by Rikki on 11/9/2017.
//

#include "TextController.h"
#include "../TextureManager.h"
#include "../VisualBoard.h"
#include "../GameObject.h"
#include <sstream>

// the current visual state of the board that will be modified
VisualBoard* currentBoardState;

// the background displayed in the visual window
GameObject* boardBackground;

// SDL feature needed to render the window
SDL_Renderer* TextController::renderer = nullptr;

/**
 * Starts the game.
 */
void TextController::go() {
	// gets the game state
    std::string modelState = this->m_model->getGameState();
	// updates the text view with the current game state
    this->m_view.updateState(modelState);
	// runs the visual window
    this->runGame("Backgammon", SDL_WINDOWPOS_UNDEFINED, SDL_WINDOWPOS_UNDEFINED, 1280, 720, false);
}

// renders the visual board
void TextController::render()
{
	SDL_RenderClear(renderer); // clears renderer memory management
	boardBackground->BoardRender();
	currentBoardState->DrawBoard();
	SDL_RenderPresent(renderer);
}

// cleans the visual window and renderers
void TextController::clean() // memory management
{
	SDL_DestroyWindow(window);
	SDL_DestroyRenderer(renderer);
	SDL_Quit();
	std::cout << "Game cleaned!" << std::endl;
}

// sets isRunning to false when the window is quit so the program shuts down
void TextController::handleEvents()
{
	SDL_Event event;
	SDL_PollEvent(&event);
	switch (event.type) {
	case SDL_QUIT:
		isRunning = false; // stops game from running on next loop when window is closed
		break;

	default:
		break;
	}
}

/**
 * Runs the game of Backgammon.
 */
void TextController::runGame(const char* title, int xpos, int ypos, int width, int height, bool fullscreen) {
	int flags = 0;

	// is the window fullscreen? (off by default but can be turned on by changing the bool in go())
	if (fullscreen)
	{
		flags = SDL_WINDOW_FULLSCREEN;
	}

	// initializes the visual window
	if (SDL_Init(SDL_INIT_EVERYTHING) == 0)
	{
		std::cout << "Subsystem initialized!..." << std::endl;

		window = SDL_CreateWindow(title, xpos, ypos, width, height, flags);
		if (window) {
			std::cout << "WINDOW CREATED" << std::endl;
		}

		renderer = SDL_CreateRenderer(window, -1, 0);

		isRunning = true;
	}
	else {
		isRunning = false;
	}

	// initializes the board in the starting configuration
	currentBoardState = new VisualBoard();

	// sets the background image to the png of the backgammon board with numbers
	boardBackground = new GameObject("Graphics/backgammon_board_numbers.png", 0, 0);

	// while loop to continually run the game
    while (true) {
		// constantly gets the game state
        std::string modelState = this->m_model->getGameState();
		// and updates the text view
        this->m_view.updateState(modelState);
		// and refreshes the text view
        this->m_view.refresh();
		// along with the visual view
		render();

        // Current color of the current Player
        Color current;
        if (this->current_player.getColor() == "Black") {
            current = BLACK;
        }
        else {
            current = WHITE;
        }

		// if the player is trying to enter a piece after it is captured and has no moves,
		// skip their turn and give control to the other player
        if (!this->anyValidEnterMoves(current)) {
            std::cout << "You do not have any valid moves. Changing turns." << std::endl;

            this->m_model->resetForTurn();
            this->changeTurns();

            continue;
        }

		// outputs the color of the player whose turn it is currently
		std::cout << "Current color: " << this->current_player.getColor() << std::endl;

		// asks the player to enter a command
        std::cout << this->current_player.getName() << ", enter a command: " << std::endl;

		// takes the input as a command
        std::string input;
        getline(std::cin, input);

        unsigned int position = input.find(' ');
        std::string token = input.substr(0, position);
        input.erase(0, position + 1);

        //end the game
        if (this->m_model->checkForVictory()) {
            std::string winner;
            if (this->m_model->getVictor() == BLACK) {
                winner += "Black ";
            }
            else if (this->m_model->getVictor() == WHITE) {
                winner += "White ";
            }
            winner += " has won the game.";
            this->restart();
        }
        else {
			// if the player uses the roll command
            if (token == "roll") {
				// if the user has already rolled, tell them so and do not roll the dice again
                if (this->m_model->rolled()) {
                    std::cout << "You already rolled." << std::endl;
                } else {
					// roll the dice in the backgammon model
                    this->m_model->rollDice();
					// pass dice rolls to currentBoardState
					currentBoardState->diceRoll(this->m_model->m_die1.getValue(), this->m_model->m_die2.getValue());
                }
            }
			// if the player uses the move command
            else if (token == "move") {
				// the user must have rolled
                if (this->m_model->rolled()) {

					// check that they have no captured pieces
                    if ((this->m_model->isWhiteCaptured() && current == WHITE)
                        || (this->m_model->isBlackCaptured() && current == BLACK)) {
                        std::cout << "You must enter your hit pieces first." << std::endl;
                        continue;
                    }

					// the starting position
                    int from = 0;
					// the destination
                    int to = 0;

                    // Making sure that there is a correct number of inputs.
                    try {
                        position = input.find(' ');
                        std::string from_string = input.substr(0, position);
                        position = input.find(' ');
                        std::string dest_string = input.substr(position);

                        stringstream ss(from_string);
                        ss >> from;

                        stringstream ss2(dest_string);
                        ss2 >> to;

						// checks that the inputs are in bounds
						if (from < 0 || from > 23) {
							throw "You cannot move a piece from an out of bounds space.";
						}
						
						if (to < 0 || to > 23) {
							throw "You cannot move a piece to a point that is out of bounds.";
						}
                    }
                    catch (const exception &e) {
                        std::cout << "Please input a valid command." << std::endl;
                        continue;
                    } 
					catch (const char * & error) {
						std::cout << error << std::endl;
					}

					// if the player's move is valid
                    if (this->m_model->isValidMove(from - 1, to - 1, this->current_player)) {
						// strings to be given values by currentBoardState->pieceValue 
						// to check if a piece should be captured
						string fromPieceValue = "na";
						string toPieceValue = "na";
                        try {
							// moves the piece in the backgammon model
                            this->m_model->move(from - 1, to - 1);
							// moves the piece in the visual window
							// if the from is the first spot in the top row
							if (from == 12) {
								// if the to is in the top row
								if (to < 12) {
									// check if a piece should be captured
									if (currentBoardState->checkSpace(0, (12 - to))) {
										// adds what color piece is at the destination and starting positions
										toPieceValue = currentBoardState->pieceValue(0, (12 - to));
										fromPieceValue = currentBoardState->pieceValue(0, 0);
										// if the pieces are different colors, 
										// send the captured piece to the correct captured slot
										if ((toPieceValue == "black") && (fromPieceValue == "white")) {
											currentBoardState->PieceMove(0, (12 - to), 0, 12);
										}
										else if ((toPieceValue == "white") && (fromPieceValue == "black")) {
											currentBoardState->PieceMove(0, (12 - to), 1, 12);
										}
									}
									// move the piece on the board
									currentBoardState->PieceMove(0, 0, 0, (12 - to));
								}
								// if the to is in the bottom row
								else if (to > 12) {
									// check if piece should be captured
									if (currentBoardState->checkSpace(1, (to - 13))) {
										// adds what color piece is at the destination and starting positions
										toPieceValue = currentBoardState->pieceValue(1, (to - 13));
										fromPieceValue = currentBoardState->pieceValue(0, 0);
										// if the pieces are different colors, 
										// send the captured piece to the correct captured slot
										if ((toPieceValue == "black") && (fromPieceValue == "white")) {
											currentBoardState->PieceMove(1, (to - 13), 0, 12);
										}
										else if ((toPieceValue == "white") && (fromPieceValue == "black")) {
											currentBoardState->PieceMove(1, (to - 13), 1, 12);
										}
									}
									// move the piece on the board
									currentBoardState->PieceMove(0, 0, 1, (to - 13));
								}
							}
							// if the from is in the top row
							else if (from < 12) {
								// if the to is the first spot in the top row
								if (to == 12) {
									// check if piece should be captured
									if (currentBoardState->checkSpace(0, 0)) {
										// adds what color piece is at the destination and starting positions
										toPieceValue = currentBoardState->pieceValue(0, 0);
										fromPieceValue = currentBoardState->pieceValue(0, (12 - from));
										// if the pieces are different colors, 
										// send the captured piece to the correct captured slot
										if ((toPieceValue == "black") && (fromPieceValue == "white")) {
											currentBoardState->PieceMove(0, 0, 0, 12);
										}
										else if ((toPieceValue == "white") && (fromPieceValue == "black")) {
											currentBoardState->PieceMove(0, 0, 1, 12);
										}
									}
									// move the piece on the board
									currentBoardState->PieceMove(0, (12 - from), 0, 0);
								}
								// if the to is in the top row
								else if (to < 12) {
									// check if piece should be captured
									if (currentBoardState->checkSpace(0, (12 - to))) {
										// adds what color piece is at the destination and starting positions
										toPieceValue = currentBoardState->pieceValue(0, (12 - to));
										fromPieceValue = currentBoardState->pieceValue(0, (12 - from));
										// if the pieces are different colors, 
										// send the captured piece to the correct captured slot
										if ((toPieceValue == "black") && (fromPieceValue == "white")) {
											currentBoardState->PieceMove(0, (12 - to), 0, 12);
										}
										else if ((toPieceValue == "white") && (fromPieceValue == "black")) {
											currentBoardState->PieceMove(0, (12 - to), 1, 12);
										}
									}
									// move the piece on the board
									currentBoardState->PieceMove(0, (12 - from), 0, (12 - to));
								}
								// if the to is in the bottom row
								else if (to > 12) {
									if (currentBoardState->checkSpace(1, (to - 13))) {
										// adds what color piece is at the destination and starting positions
										toPieceValue = currentBoardState->pieceValue(1, (to - 13));
										fromPieceValue = currentBoardState->pieceValue(0, (12 - from));
										// if the pieces are different colors, 
										// send the captured piece to the correct captured slot
										if ((toPieceValue == "black") && (fromPieceValue == "white")) {
											currentBoardState->PieceMove(1, (to - 13), 0, 12);
										}
										else if ((toPieceValue == "white") && (fromPieceValue == "black")) {
											currentBoardState->PieceMove(1, (to - 13), 1, 12);
										}
									}
									// move the piece on the board
									currentBoardState->PieceMove(0, (12 - from), 1, (to - 13));
								}
							}
							// if the from is in the bottom row
							else if (from > 12) {
								// if the to is the first spot in the top row
								if (to == 12) {
									// check if piece should be captured
									if (currentBoardState->checkSpace(0, 0)) {
										// adds what color piece is at the destination and starting positions
										toPieceValue = currentBoardState->pieceValue(0, 0);
										fromPieceValue = currentBoardState->pieceValue(1, (from - 13));
										// if the pieces are different colors, 
										// send the captured piece to the correct captured slot
										if ((toPieceValue == "black") && (fromPieceValue == "white")) {
											currentBoardState->PieceMove(0, 0, 0, 12);
										}
										else if ((toPieceValue == "white") && (fromPieceValue == "black")) {
											currentBoardState->PieceMove(0, 0, 1, 12);
										}
									}
									// move the piece on the board
									currentBoardState->PieceMove(1, (from - 13), 0, 0);
								}
								// if the to is in the top row
								else if (to < 12) {
									// check if piece should be captured
									if (currentBoardState->checkSpace(0, (12 - to))) {
										// adds what color piece is at the destination and starting positions
										toPieceValue = currentBoardState->pieceValue(0, (12 - to));
										fromPieceValue = currentBoardState->pieceValue(1, (from - 13));
										// if the pieces are different colors, 
										// send the captured piece to the correct captured slot
										if ((toPieceValue == "black") && (fromPieceValue == "white")) {
											currentBoardState->PieceMove(0, (12 - to), 0, 12);
										}
										else  if ((toPieceValue == "white") && (fromPieceValue == "black")) {
											currentBoardState->PieceMove(0, (12 - to), 1, 12);
										}
									}
									// move the piece on the board
									currentBoardState->PieceMove(1, (from - 13), 0, (12 - to));
								}
								// if the to is in the bottom row
								else if (to > 12) {
									// check if piece should be captured
									if (currentBoardState->checkSpace(1, (to - 13))) {
										// adds what color piece is at the destination and starting positions
										toPieceValue = currentBoardState->pieceValue(1, (to - 13));
										fromPieceValue = currentBoardState->pieceValue(1, (from - 13));
										// if the pieces are different colors, 
										// send the captured piece to the correct captured slot
										if ((toPieceValue == "black") && (fromPieceValue == "white")) {
											currentBoardState->PieceMove(1, (to - 13), 0, 12);
										}
										else if ((toPieceValue == "white") && (fromPieceValue == "black")) {
											currentBoardState->PieceMove(1, (to - 13), 1, 12);
										}
									}
									// move the piece on the board
									currentBoardState->PieceMove(1, (from - 13), 1, (to - 13));
								}
							}
                        }
                        catch (const char * &error) {
                            std::cout << error << std::endl;
                        }
                    }
					else {
						std::cout << "Please input a valid move." << std::endl;
					}
                }
			// if the player is trying to deposit a piece into their final capture slot
            } else if (token == "bear") {
                if (this->m_model->rolled()) {
					int from = 0;

					try {
						position = input.find(' ');
						std::string from_string = input.substr(0, position);
						position = input.find(' ');
						std::string dest_string = input.substr(position);

						stringstream ss(from_string);
						ss >> from;
					} 
					catch (const exception & error) {
						std::cout << "Please input a valid command." << std::endl;
					}

                    if (current_player.getColor() == "Black") {
                        if (this->m_model->isValidBear(from - 1, 25 - (from - 1), current_player)) {
							// move the piece to the black capture slot in the backgammon model
                            this->m_model->bear(from, BLACK);
							// move the piece to the black capture slot in the visual
							currentBoardState->PieceMove(1, (24 - from), 1, 13);
                        }
                    }
                    else if (current_player.getColor() == "White") {
                        if (this->m_model->isValidBear(from - 1, from - 1, current_player)) {
							// move the piece to the white capture slot in the backgammon model
                            this->m_model->bear(from, WHITE);
							// move the piece to the white capture slot in the visual
							currentBoardState->PieceMove(0, (12 - from), 0, 13);
                        }
                    }
                }
			// if the player wants to double
            } else if (token == "double") {
				// prevent them if they've already used it this turn
                if (this->m_model->doubled()) {
                    std::cout << "You already rolled the doubling cube this turn." << std::endl;
				// prevent them if they've already rolled this turn
                } else if (this->m_model->rolled()) {
                    std::cout << "You cannot roll the doubling cube once you've rolled the dice." << std::endl;
                }
                else {
					// asks the other player if they accept the double
                    if (this->m_model->getPlayer1() == current_player)  {
                        std::cout << this->m_model->getPlayer2().getName() << ", do you accept doubling the stakes?"
                                                                                        << std::endl;

                        getline(std::cin, token);

						// if they say anything but "yes", they forfeit and the game restarts
                        if (token != "yes") {
                            this->m_model->getPlayer2().addPoints(1);
							clean(); // destroys old window
							currentBoardState->diceRoll(0, 0); // resets die
							currentBoardState->setDoublingCube(0); // resets doubling cube
                            this->m_model->restart();
                        }
						// if they say "yes", activate the doubling cube
                        else {
                            this->m_model->rollDoublingCube();
							currentBoardState->doublingCubeIncrease();
                        }
                    }
					// the same operation for player2, since a player cannot use the doubling cube twice in a row
					// and has to wait for the other player to use it first
                    else if (this->m_model->getPlayer2() == current_player) {
                        std::cout << this->m_model->getPlayer1().getName() << ", do you accept doubling the stakes? (yes or no)"
                                                                                        << std::endl;

                        getline(std::cin, token);

                        if (token != "yes") {
                            this->m_model->getPlayer1().addPoints(1);
							clean(); // destroys old window
							currentBoardState->diceRoll(0, 0); // resets die
							currentBoardState->setDoublingCube(0); // resets doubling cube
                            this->m_model->restart();
                        }
                        else {
                            this->m_model->rollDoublingCube();
							currentBoardState->doublingCubeIncrease();
                        }
                    }

                }
			// if the player has a captured piece and wants to enter it back on the board
            } else if (token == "enter") {

				// if the current player has a piece of their's captured
                if ((this->m_model->isBlackCaptured() && current == BLACK)
                    || (this->m_model->isWhiteCaptured() && current == WHITE)) {

                    if (!this->m_model->rolled()) {
                        std::cout << "You must roll the dice first." << std::endl;
                        continue;
                    }
                    else {
                        int from = 0;
                        try {
                            position = input.find(' ');
                            std::string from_string = input.substr(0, position);

                            stringstream ss(from_string);
                            ss >> from;
                        }
                        catch (const exception & e) {
                            std::cout << "Please only input a valid enter command." << std::endl;
                        }

                        try {
							// enters piece into board in backgammon model
                            this->m_model->enterPiece(current, from - 1);
							// drawing entered captured pieces back to board
							if (current == BLACK) {
								currentBoardState->PieceMove(0, 12, 0, (12 - from));
							} else if (current == WHITE) {
								currentBoardState->PieceMove(1, 12, 1, (12 - from));
							} 
						}
                        catch (const char * & error) {
                            std::cout << error << std::endl;
                        }

                    }


                }
                else {
                    std::cout << "You do not have any pieces to enter." << std::endl;
                }
			}
			// if the player wants to show the possible moves of a piece
			else if (token == "possible") {
			
				// they have to have rolled first
				if (this->m_model->rolled()) {
					int from = 0;
					try {
						position = input.find(' ');
						std::string from_string = input.substr(0, position);
						stringstream ss(from_string);
						ss >> from;
					}
					catch (const exception & error) {
						std::cout << "Please input a valid command." << std::endl;
					}

					// gets the possible moves from the backgammon model
					vector<int> spaces = this->m_model->getPossibleMoves(this->current_player, from - 1);
					// adds the possibilites from the backgammon model in an array
					int array[4][2];
					for (int x = 0; x < spaces.size(); x++) {
						// if the indicator is on the top half but not the first spot
						if (spaces[x] < 12) {
							array[x][0] = 0;
							array[x][1] = (12 - spaces[x]);
						}
						// if the indicator is the first spot on the top half 
						else if (spaces[x] == 12) {
							array[x][0] = 0;
							array[x][1] = 0;
						}
						// if the indicator is on the bottom half 
						else if (spaces[x] > 12) {
							array[x][0] = 1;
							array[x][1] = (spaces[x] - 13);
						}
					}
					// draws the possible indicators to the board using the array
					currentBoardState->possibleIndicators(array, spaces.size());
				}
				else {
					std::cout << "You must roll the dice first." << std::endl;
				}
			}
			// if the player wants to quit
			else if (token == "quit") {
                std::cout << "Goodbye." << std::endl;
                exit(1);
            }
        }

        // Changes turns if needed.
       this->changeTurns();
    }
}

// are there any valid moves for the current player who wants to move a captured piece in?
bool TextController::anyValidEnterMoves(Color current) {

	return this->m_model->anyValidEnterMoves(current);
}

// changes whose turn it is
void TextController::changeTurns() {

    if ((this->m_model->getNumberOfMoves() == 0) && this->m_model->rolled()) {
        if (this->current_player == this->m_model->getPlayer1()) {
            this->current_player = this->m_model->getPlayer2();
        } else {
            this->current_player = this->m_model->getPlayer1();
        }

        this->m_model->resetForTurn();
    }
}

// restarts the game
void TextController::restart() {
    BackgammonModel *newGame = new BackgammonModel;
    newGame->setPoints(this->m_model->getPoints());
    newGame->setPlayers(this->m_model->getPlayer1(), this->m_model->getPlayer2());
    TextView view = TextView();

    delete this->m_model;

    this->m_model = newGame;

    this->go();
}
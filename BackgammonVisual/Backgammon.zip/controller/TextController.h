//
// Created by Rikki on 11/9/2017.
//

#ifndef BACKGAMMON_TEXTCONTROLLER_H
#define BACKGAMMON_TEXTCONTROLLER_H

#include "IController.h"
#include "../model/BackgammonModel.h"
#include "../view/TextView.h"
#include "../VisualBoard.h"

/**
 * Represents a controller for a text Backgammon game.
 */
class TextController : public IController {
    
public:
    // Constructor for a TextController
    TextController(TextView view, BackgammonModel *model) : m_view(view), m_model(model) {}
    // Called and starts the game of backgammon
    void go();
	// runs the visual / text input parts of the game with the given settings
    void runGame(const char* title, int xpos, int ypos, int width, int height, bool fullscreen);
	void clean();

	// SDL feature needed to render the visuals
	static SDL_Renderer* renderer;

	void handleEvents();

	// called to render the visuals
	void render();

	bool running() { return isRunning; } // is game running?


private:
	// holds the current data of the game
    BackgammonModel * m_model;
	// outputs the text
    TextView m_view;
	// sets the current player from the BackgammonModel
    Player current_player = m_model->getPlayer1();
    // Deals with input if the user wants to enter a piece after it is captured
    bool anyValidEnterMoves(Color current);
	// changes player turns
    void changeTurns();
	// restarts the game
    void restart();
	// SDL feature needed to generate a window
	SDL_Window *window;
	bool isRunning = false; // is the game running? starts as false

};
#endif //BACKGAMMON_TEXTCONTROLLER_H

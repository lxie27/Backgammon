#include "game.h"
#include "TextureManager.h"
#include "GameObject.h"
#include "VisualBoard.h"

GameObject* boardBackgroundT;

VisualBoard* currentBoardStateT;

SDL_Renderer* Game::renderer = nullptr;

Game::Game() {}

Game::~Game() {}

int ticker = 0;

void Game::init(const char* title, int xpos, int ypos, int width, int height, bool fullscreen)
{
	int flags = 0;
	if (fullscreen)
	{
		flags = SDL_WINDOW_FULLSCREEN;
	}

	if (SDL_Init(SDL_INIT_EVERYTHING) == 0)
	{
		std::cout << "Subsystem initialized!..." << std::endl;

		window = SDL_CreateWindow(title, xpos, ypos, width, height, flags);
		if (window) {
			std::cout << "WINDOW CREATED" << std::endl;
		}

		renderer = SDL_CreateRenderer(window, -1, 0);

		isRunning = true;
	}
	else {
		isRunning = false;
	}

	boardBackgroundT = new GameObject("Graphics/backgammon_board.png", 0, 0);
	currentBoardStateT = new VisualBoard();
	/* USAGE EXAMPLES:
	currentBoardState->PieceMove(0, 0, 1, 13);

	Will move the white piece on the first row in the first spot
	to it's captured slot in the second row.

	To move any pieces like this, call currentBoardState->PieceMove(x1, y1, x2, y2)
	where x1, y1 is the starting row and column of the piece and x2, y2 is the ending position

	COMPARED TO HOW THE SPOTS ARE SET UP IN THE CODE:
	0,12 for the input here would be the 1st spot,
	0,0 would be the 12th spot,
	1,0 would be the 13th spot,
	1,12 would be the 24th spot
	0,6 and 1,6 are the captured pieces on the middle spots,
	so if you are trying to get to the 7th spot, it is 0,7, NOT 0,6

	0,13 and 1,13 are the final capture slots (black at 0,13, white at 1,13)

	currentBoardState->diceRoll(1, 1);

	This will set the die roll to 1 and 1 and create the double images as well

	currentBoardState->doublingCubeIncrease();

	Increases the doubling cube by 1 (multiplies it by 2)

	int array[4][2] = { { 0,7 },{ 1,2 },{ 1,3 },{ 1,4 } };
	currentBoardState->possibleIndicators(array, 2);

	This will create an array of spots where the indicators for possible moves will be shown,
	here being 0,7 (the 6th spot), 1,2 (the 15th spot), 1,3 (the 16th), and 1,4 (the 17th)

	It will then place those indicators on the board, but the 2 in the second variable input
	will limit it to two indicators being shown, as this is how many possible moves there are
	*/
	/*currentBoardState->PieceMove(0, 0, 1, 13);
	currentBoardState->PieceMove(0, 0, 1, 13);
	currentBoardState->PieceMove(1, 0, 0, 13);
	currentBoardState->PieceMove(1, 0, 0, 13);
	currentBoardState->PieceMove(0, 0, 1, 13);
	currentBoardState->PieceMove(0, 0, 1, 13);
	currentBoardState->PieceMove(0, 0, 1, 13);
	// WHITE SPOT MUST BE CLEAR BEFORE BLACK PIECES CAN MOVE ONTO IT,
	// until capture moves them both
	currentBoardState->PieceMove(1, 0, 0, 0);
	currentBoardState->PieceMove(1, 0, 0, 0);
	currentBoardState->PieceMove(1, 0, 0, 0);
	currentBoardState->PieceMove(0, 0, 0, 12);
	currentBoardState->PieceMove(1, 4, 1, 12);
	// imposisble move but still runs, adds a white piece to capture from a
	// black piece : currentBoardState->PieceMove(0, 0, 1, 6);
	currentBoardState->PieceMove(1, 4, 1, 11);
	currentBoardState->PieceMove(1, 4, 1, 11);
	// impossible move, no white pieces left: currentBoardState->PieceMove(1, 4, 1, 6);
	// impossible move : currentBoardState->PieceMove(1, 0, 1, 6);
	currentBoardState->diceRoll(1, 1);

	currentBoardState->doublingCubeIncrease();
	currentBoardState->doublingCubeIncrease();
	currentBoardState->doublingCubeIncrease();
	/*
	currentBoardState->PieceMove(0, 0, 1, 13);
	currentBoardState->PieceMove(0, 0, 1, 13);
	currentBoardState->PieceMove(0, 0, 1, 13);
	currentBoardState->PieceMove(1, 0, 0, 13);
	currentBoardState->PieceMove(1, 0, 0, 13);
	currentBoardState->PieceMove(0, 0, 1, 13);*/
	/*
	// piece capture
	currentBoardState->PieceMove(0, 0, 0, 1);
	// first space is alone with one black
	// piece to be captured is moved to capture zone first
	currentBoardState->PieceMove(0, 0, 0, 12);
	// then capturing piece is moved to captured zone 
	currentBoardState->PieceMove(0, 11, 0, 0);
	// int array[4][2] = { { 0,7 },{ 1,2 },{ 1,3 },{ 1,4 } };
	// currentBoardState->possibleIndicators(array, 2);
	// currentBoardState->diceRoll(5, 5);*/
}

void Game::handleEvents()
{
	SDL_Event event;
	SDL_PollEvent(&event);
	switch (event.type) {
	case SDL_QUIT:
		isRunning = false; // stops game from running on next loop when window is closed
		break;

	default:
		break;
	}
}

void Game::update()
{
	// blackPieceMove->Update();
	// on second tick
	ticker++;
	if (ticker > 1) {
		int scolumn = 0;
		int srow = 0;
		int ecolumn = 0;
		int erow = 0;
		std::cout << "Enter starting column" << std::endl;
		std::cin >> scolumn;
		std::cout << "Enter starting row" << std::endl;
		std::cin >> srow;
		std::cout << "Enter ending column" << std::endl;
		std::cin >> ecolumn;
		std::cout << "Enter ending row" << std::endl;
		std::cin >> erow;
		currentBoardStateT->PieceMove(srow, scolumn, erow, ecolumn);
	}
}

void Game::render()
{
	SDL_RenderClear(renderer); // clears renderer memory management
	boardBackgroundT->BoardRender();
	currentBoardStateT->DrawBoard();
	SDL_RenderPresent(renderer);
}

void Game::clean() // memory management
{
	SDL_DestroyWindow(window);
	SDL_DestroyRenderer(renderer);
	SDL_Quit();
	std::cout << "Game cleaned!" << std::endl;
}
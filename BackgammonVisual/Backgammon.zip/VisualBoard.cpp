#include "VisualBoard.h"
#include "TextureManager.h"

int extraCount = 0; // count for addtional number of pieces to be placed on a space past 1

int doublingCubePowerCount = 0; // determines graphic used for doubling cube
								// based on power of 2 (doubling cube starts off as 1 = 2^0, once it is used it will become 2 = 2^1)

int indicatorCount = 0; // the number of additional indicators to be used past 1
int indicatorColumn = 0; // column on the board that will be indicated 
int indicatorRow = 0; // row on the board that will be indicated 
int indicatorPositions[4][2]; // positions of the indicators [row,column]

int dice1Value = 0; // the value of the first dice rolled

int dice2Value = 0; // the value of the second dice rolled

					// the board! in it's default state
					// columns 0-5 in both rows are the first six spots on the first half of the board
					// columns 6-11 in both rows are the next six spots on the second half of the board
					// column 12 in the top row is the black captured slot
					// column 12 in the bottom row is the white captured slot
					// column 13 in the top row is the black final container slot
					// column 13 in the bottom row is the white final container slot
					// column 14 in the top row holds the indicators
					// column 14 in the bottom row holds the doubling cube
					// columns 15 and 16 in each row holds a die
					// the games ends when top column 13 equals 1115 (15 black pieces inside their final container slot)
					// or bottom column 13 equals 1015 (15 white pieces inside their final container slot)
int initialBoardLayout[2][17] = {
	// starting state 
	{ 105,0,0,0,3,0,5,0,0,0,0,102,0,0,300,500,600 }, // first row holds the top level
	{ 5,0,0,0,103,0,105,0,0,0,0,2,0,0,400,500,600 } // second row holds the bottom level
	// starting state (opposite)
	/*{ 5,0,0,0,103,0,105,0,0,0,0,2,0,0,300,500,600 }, // first row holds the top level
	{ 105,0,0,0,3,0,5,0,0,0,0,102,0,0,400,500,600 }*/ // second row holds the bottom level
};



VisualBoard::VisualBoard()
{
	// loads all the textures for pieces and indicators
	white_piece = TextureManager::LoadTexture("Graphics/white_piece.png");
	black_piece = TextureManager::LoadTexture("Graphics/black_piece.png");
	captured_white_piece = TextureManager::LoadTexture("Graphics/white_piece_captured.png");
	captured_black_piece = TextureManager::LoadTexture("Graphics/black_piece_captured.png");
	possible_indicator = TextureManager::LoadTexture("Graphics/possible_indicator.png");
	possible_indicator_upside_down = TextureManager::LoadTexture("Graphics/possible_indicator_upside_down.png");

	// copies the starting board info into pieceLayout
	LoadBoard(initialBoardLayout);

	// sets the generic dimensions for the pieces
	src.x = src.y = 0;
	src.w = src.h = 150;
	dest.w = dest.h = 64;
	dest.x = dest.y = 0;
}

VisualBoard::~VisualBoard() {}

// loads the default board into pieceLayout
void VisualBoard::LoadBoard(int arr[2][17])
{
	for (int row = 0; row < 2; row++) {
		for (int column = 0; column < 17; column++) {
			pieceLayout[row][column] = arr[row][column];
		}
	}
}

// draws the assets onto the board depending on the values
// inside each [row][column] of pieceLayout
void VisualBoard::DrawBoard() {
	int type = 0;

	// first row (the top half)
	for (int row = 0; row < 1; row++) {
		for (int column = 0; column < 17; column++) {
			// gets the value of the current row and column in pieceLayout
			type = pieceLayout[row][column];

			// for the first half of the board
			dest.x = 172 + (column * 75);
			dest.y = 40;

			// for the second half of the board, after the captured piece
			if (column >= 6) {
				dest.x = 145 + ((column + 1) * 75);
				dest.y = 40;
			}

			// for the middle row of captured pieces
			if (column == 12) {
				dest.x = 610;
				dest.y = 394;
			}

			// for the final row of captured pieces
			if (column == 13) {
				dest.x = 165 + (column * 75);
				dest.y = 40;
			}

			// for the indicators
			if (column == 14) {
				dest.x = 168;
				dest.y = 40;
			}

			// for the first dice
			if (column == 15) {
				dest.x = 300;
				dest.y = 330;
			}

			if (type == 0) { // no pieces left or empty starting space

			}
			else if (type >= 1 && type < 5) { // 1 to 4 white pieces
				extraCount = type - 1;
				TextureManager::Draw(white_piece, src, dest);
				for (int x = 0; x < extraCount; x++) {
					dest.y = dest.y + 64;
					TextureManager::Draw(white_piece, src, dest);
				}
				dest.y = dest.y - (64 * extraCount);
			}
			else if (type >= 5 && type < 16) { // 5 to 15 white pieces (the max)
				extraCount = type - 1;
				TextureManager::Draw(white_piece, src, dest);
				for (int x = 0; x < extraCount; x++) {
					dest.y = dest.y + (192 / extraCount);
					TextureManager::Draw(white_piece, src, dest);
				}
				dest.y = dest.y - 192;
			}
			else if (type >= 101 && type < 105) { // 1 to 4 black pieces
				extraCount = type - 101;
				TextureManager::Draw(black_piece, src, dest);
				for (int x = 0; x < extraCount; x++) {
					dest.y = dest.y + 64;
					TextureManager::Draw(black_piece, src, dest);
				}
				dest.y = dest.y - (64 * extraCount);
			}
			else if (type >= 105 && type < 116) { // 5 to 15 black pieces (the max)
				extraCount = type - 101;
				TextureManager::Draw(black_piece, src, dest);
				for (int x = 0; x < extraCount; x++) {
					dest.y = dest.y + (192 / extraCount);
					TextureManager::Draw(black_piece, src, dest);
				}
				dest.y = dest.y - 192;
			}
			else if (type >= 1101 && type < 1116) { // 1 to 15 captured black pieces (the max)
				src.w = 154;
				src.h = 47;
				dest.w = 64;
				dest.h = 19.53;
				extraCount = type - 1101;
				TextureManager::Draw(captured_black_piece, src, dest);
				for (int x = 0; x < extraCount; x++) {
					dest.y = dest.y + 20;
					TextureManager::Draw(captured_black_piece, src, dest);
				}
				dest.y = dest.y - (20 * extraCount);
				src.w = src.h = 150;
				dest.w = dest.h = 64;
			}
			else if (type >= 300 && type <= 304) { // 1 to 4 possible move indicators
				src.w = 180;
				src.h = 789;
				dest.h = 280;
				dest.w = 73;
				indicatorCount = type - 300; // how many indicators will be drawn?
				for (int x = 0; x < indicatorCount; x++) {
					indicatorRow = indicatorPositions[x][0]; // gets the row placement of the xth indicator
					indicatorColumn = indicatorPositions[x][1]; // gets the column placement of the xth indicator
					if (indicatorRow == 0) { // if the indicator is on the top half...
						if (indicatorColumn <= 5) { // and in the first half, move it's position to match the pieces
							dest.x = dest.x + (75 * indicatorColumn);
							TextureManager::Draw(possible_indicator, src, dest);
							dest.x = dest.x - (75 * indicatorColumn);
						}
						else if (indicatorColumn >= 6) { // or in the second half, move it's position to match the pieces
							dest.x = dest.x + (75 * (indicatorColumn + 1)) - 27;
							TextureManager::Draw(possible_indicator, src, dest);
							dest.x = dest.x - (75 * (indicatorColumn + 1)) + 27;
						}
					}

					if (indicatorRow == 1) { // if the indicator is on the bottom half...
						if (indicatorColumn <= 5) { // and in the first half, move it's position to match the pieces
							dest.x = dest.x + (75 * indicatorColumn);
							dest.y = 400;
							TextureManager::Draw(possible_indicator_upside_down, src, dest);
							dest.x = dest.x - (75 * indicatorColumn);
							dest.y = 40;
						}
						else if (indicatorColumn >= 6) { // and in the second half, move it's position to match the pieces
							dest.x = dest.x + (75 * (indicatorColumn + 1)) - 27;
							dest.y = 400;
							TextureManager::Draw(possible_indicator_upside_down, src, dest);
							dest.x = dest.x - (75 * (indicatorColumn + 1)) + 27;
							dest.y = 40;
						}
					}
				}

				// return the src and dest values to their generics
				src.w = src.h = 150;
				dest.h = dest.w = 64;

				// makes sure the indicators will not be drawn next turn
				type = 300;
			}
			else if (type == 500) { // the first die

									// set graphic dimensions to the dice image's size
				src.w = src.h = 256;

				if (dice1Value == 0) { // the die has not been rolled yet so should not be displayed
				}
				// gives the die graphics based on how it rolled
				else if (dice1Value == 1) {
					die1 = TextureManager::LoadTexture("Graphics/diceSide1.png");
				}
				else if (dice1Value == 2) {
					die1 = TextureManager::LoadTexture("Graphics/diceSide2.png");
				}
				else if (dice1Value == 3) {
					die1 = TextureManager::LoadTexture("Graphics/diceSide3.png");
				}
				else if (dice1Value == 4) {
					die1 = TextureManager::LoadTexture("Graphics/diceSide4.png");
				}
				else if (dice1Value == 5) {
					die1 = TextureManager::LoadTexture("Graphics/diceSide5.png");
				}
				else if (dice1Value == 6) {
					die1 = TextureManager::LoadTexture("Graphics/diceSide6.png");
				}
				else {
					break;
				}

				// draw the die
				TextureManager::Draw(die1, src, dest);

				// set dimensions back to their generics
				src.w = src.h = 150;
				dest.w = dest.h = 64;
			}
			else if (type == 600) { // the first "double" die
				if (dice2Value == dice1Value) { // only activated if the player rolls a double

												// set graphic dimensions to the dice image's size
					src.w = src.h = 256;

					if (dice1Value == 0) { // the dice has not been rolled yet so should not be displayed
					}
					// gives the die graphics based on how die1 rolled, since it is a double of that die
					else if (dice1Value == 1) {
						die3 = TextureManager::LoadTexture("Graphics/diceSide1.png");
					}
					else if (dice1Value == 2) {
						die3 = TextureManager::LoadTexture("Graphics/diceSide2.png");
					}
					else if (dice1Value == 3) {
						die3 = TextureManager::LoadTexture("Graphics/diceSide3.png");
					}
					else if (dice1Value == 4) {
						die3 = TextureManager::LoadTexture("Graphics/diceSide4.png");
					}
					else if (dice1Value == 5) {
						die3 = TextureManager::LoadTexture("Graphics/diceSide5.png");
					}
					else if (dice1Value == 6) {
						die3 = TextureManager::LoadTexture("Graphics/diceSide6.png");
					}
					else {
						break;
					}

					// set dimensions to be on the opposite side of the board from first die
					dest.x = 798;
					dest.y = 330;

					// draw the die
					TextureManager::Draw(die3, src, dest);

					// set dimensions back to their generics
					src.w = src.h = 150;
					dest.w = dest.h = 64;
				}
			}
			else {
				break;
			}
		}
	}

	// second row (the bottom half)
	for (int row = 1; row < 2; row++) {
		for (int column = 0; column < 17; column++) {
			// gets the value of the current row and column in pieceLayout
			type = pieceLayout[row][column];

			// for the first half of the board
			dest.x = 172 + (column * 75);
			dest.y = 616;

			// for the second half of the board, after the captured piece
			if (column >= 6) {
				dest.x = 145 + ((column + 1) * 75);
				dest.y = 616;
			}

			// for the middle row of captured pieces
			if (column == 12) {
				dest.x = 610;
				dest.y = 330;
			}

			// for the final row of captured pieces
			if (column == 13) {
				dest.x = 165 + (column * 75);
				dest.y = 660;
			}

			// for the doubling cube
			if (column == 14) {
				dest.x = 1200;
				dest.y = 330;
			}

			// for the second dice
			if (column == 15) {
				dest.x = 425;
				dest.y = 330;
			}

			if (type == 0) { // no pieces left or empty starting space

			}
			else if (type >= 1 && type < 5) { // 1 to 4 white pieces
				extraCount = type - 1;
				TextureManager::Draw(white_piece, src, dest);
				for (int x = 0; x < extraCount; x++) {
					dest.y = dest.y - 64;
					TextureManager::Draw(white_piece, src, dest);
				}
				dest.y = dest.y + (64 * extraCount);
			}
			else if (type >= 5 && type < 16) { // 5 to 15 white pieces (the max)
				extraCount = type - 1;
				TextureManager::Draw(white_piece, src, dest);
				for (int x = 0; x < extraCount; x++) {
					dest.y = dest.y - (192 / extraCount);
					TextureManager::Draw(white_piece, src, dest);
				}
				dest.y = dest.y + 192;
			}
			else if (type >= 101 && type < 105) { // 1 to 4 black pieces
				extraCount = type - 101;
				TextureManager::Draw(black_piece, src, dest);
				for (int x = 0; x < extraCount; x++) {
					dest.y = dest.y - 64;
					TextureManager::Draw(black_piece, src, dest);
				}
				dest.y = dest.y + (64 * extraCount);
			}
			else if (type >= 105 && type < 116) { // 5 to 15 black pieces (the max)
				extraCount = type - 101;
				TextureManager::Draw(black_piece, src, dest);
				for (int x = 0; x < extraCount; x++) {
					dest.y = dest.y - (192 / extraCount);
					TextureManager::Draw(black_piece, src, dest);
				}
				dest.y = dest.y + 192;
			}
			else if (type >= 1001 && type < 1016) { // 1 to 15 captured white pieces (the max)
				src.w = 154;
				src.h = 47;
				dest.w = 64;
				dest.h = 19.53;
				extraCount = type - 1001;
				TextureManager::Draw(captured_white_piece, src, dest);
				for (int x = 0; x < extraCount; x++) {
					dest.y = dest.y - 20;
					TextureManager::Draw(captured_white_piece, src, dest);
				}
				dest.y = dest.y + (20 * extraCount);
				src.w = src.h = 150;
				dest.w = dest.h = 64;
			}
			else if (type == 400) { // the doubling cube

									// set graphics dimensions to the doubling cube's image
				src.w = src.h = 256;

				// gives the doubling cube graphics based on its current value in the game
				if (doublingCubePowerCount == 0) {
					doubling_cube = TextureManager::LoadTexture("Graphics/doublingCube0.png");
				}
				else if (doublingCubePowerCount == 1) {
					doubling_cube = TextureManager::LoadTexture("Graphics/doublingCube1.png");
				}
				else if (doublingCubePowerCount == 2) {
					doubling_cube = TextureManager::LoadTexture("Graphics/doublingCube2.png");
				}
				else if (doublingCubePowerCount == 3) {
					doubling_cube = TextureManager::LoadTexture("Graphics/doublingCube3.png");
				}
				else if (doublingCubePowerCount == 4) {
					doubling_cube = TextureManager::LoadTexture("Graphics/doublingCube4.png");
				}
				else if (doublingCubePowerCount == 5) {
					doubling_cube = TextureManager::LoadTexture("Graphics/doublingCube5.png");
				}
				else if (doublingCubePowerCount == 6) {
					doubling_cube = TextureManager::LoadTexture("Graphics/doublingCube6.png");
				}
				else {
					break;
				}

				// draw the doubling cube
				TextureManager::Draw(doubling_cube, src, dest);

				// set dimensions back to their generics
				src.w = src.h = 150;
				dest.w = dest.h = 64;
			}
			else if (type == 500) { // the second die

									// set graphic dimensions to the dice image's size
				src.w = src.h = 256;

				if (dice2Value == 0) { // the dice has not been rolled yet so should not be displayed
				}
				// gives the die graphics based on how it rolled
				else if (dice2Value == 1) {
					die2 = TextureManager::LoadTexture("Graphics/diceSide1.png");
				}
				else if (dice2Value == 2) {
					die2 = TextureManager::LoadTexture("Graphics/diceSide2.png");
				}
				else if (dice2Value == 3) {
					die2 = TextureManager::LoadTexture("Graphics/diceSide3.png");
				}
				else if (dice2Value == 4) {
					die2 = TextureManager::LoadTexture("Graphics/diceSide4.png");
				}
				else if (dice2Value == 5) {
					die2 = TextureManager::LoadTexture("Graphics/diceSide5.png");
				}
				else if (dice2Value == 6) {
					die2 = TextureManager::LoadTexture("Graphics/diceSide6.png");
				}
				else {
					break;
				}

				// draw the die
				TextureManager::Draw(die2, src, dest);

				// set dimensions back to their generics
				src.w = src.h = 150;
				dest.w = dest.h = 64;
			}
			else if (type == 600) { // the second "double" die
				if (dice2Value == dice1Value) { // only activated if the player rolls a double

												// set graphic dimensions to the dice image's size
					src.w = src.h = 256;

					if (dice2Value == 0) { // the dice has not been rolled yet so should not be displayed
					}
					// gives the die graphics based on how die2 rolled, since it is a double of that die
					// interchangable with dice1Value since they would both have to be the same
					else if (dice2Value == 1) {
						die4 = TextureManager::LoadTexture("Graphics/diceSide1.png");
					}
					else if (dice2Value == 2) {
						die4 = TextureManager::LoadTexture("Graphics/diceSide2.png");
					}
					else if (dice2Value == 3) {
						die4 = TextureManager::LoadTexture("Graphics/diceSide3.png");
					}
					else if (dice2Value == 4) {
						die4 = TextureManager::LoadTexture("Graphics/diceSide4.png");
					}
					else if (dice2Value == 5) {
						die4 = TextureManager::LoadTexture("Graphics/diceSide5.png");
					}
					else if (dice2Value == 6) {
						die4 = TextureManager::LoadTexture("Graphics/diceSide6.png");
					}
					else {
						break;
					}

					// set dimensions to be the opposite side of the board from second die
					dest.x = 923;
					dest.y = 330;

					// draw the die
					TextureManager::Draw(die4, src, dest);

					// set dimensions back to their generics
					src.w = src.h = 150;
					dest.w = dest.h = 64;
				}
			}
			else {
				break;
			}
		}
	}
}

// draws the board after a move is made
void VisualBoard::PieceMove(int startingRow, int startingColumn, int destinationRow, int destinationColumn) {
	int start = 0;
	int end = 0;
	start = pieceLayout[startingRow][startingColumn];
	end = pieceLayout[destinationRow][destinationColumn];
	if (destinationColumn == 13 && destinationRow == 0 && end == 0) { // first final capture for black 
		end += 1101;
	}
	else if (destinationColumn == 13 && destinationRow == 1 && end == 0) { // first final capture for white
		end += 1001;
	}
	else if (end == 0 && start > 100) { // if end is a blank space and start has at least one black piece in it, change end to a black piece
		end += 101;
	}
	else {
		end += 1;
	}

	if (start == 101) { // if start was a single black piece, change start to be empty
		start -= 101;
	}
	else {
		start -= 1;
	}

	// set the space in pieceLayout to the changed values
	pieceLayout[startingRow][startingColumn] = start;
	pieceLayout[destinationRow][destinationColumn] = end;

	// then draw the board
	DrawBoard();
}

// adds the rolled dice values into the two dice to determine the side they show
void VisualBoard::diceRoll(int diceRoll1, int diceRoll2) {
	dice1Value = diceRoll1;
	dice2Value = diceRoll2;
	DrawBoard();
}

// adds a point to cubePowerCount when a player uses it in the game
void VisualBoard::doublingCubeIncrease() {
	doublingCubePowerCount++;
	DrawBoard();
}

// takes in the positions of the indicators, as well as how many possibilites there are,
// and maps that info to the indicatorPositions array, which is taken in by DrawBoard
// to place each indicator on the board and remove them on the next move
void VisualBoard::possibleIndicators(int positions[4][2], int possibilities) {

	// copies positions into indicatorPositions
	for (int row = 0; row < 4; row++) {
		for (int column = 0; column < 2; column++) {
			indicatorPositions[row][column] = positions[row][column];
		}
	}

	// changes the current indicator value to reflect the number of possible indicators to display
	pieceLayout[0][14] = 300 + possibilities;

	// draws the board
	DrawBoard();
}

// sets the doubling cube value back to a given int
// used by TextController to reset the doublingCube when
// a forfeit by denying the proposal occurs
void VisualBoard::setDoublingCube(int value) {
	doublingCubePowerCount = value;
}

// outputs a string of what color the pieces in the given row and column are
const char * VisualBoard::pieceValue(int row, int column) {
	if ((pieceLayout[row][column]) < 16) {
		return "white";
	}
	else {
		return "black";
	}
}

// checks if there is currently one piece of a space, either one black or white piece
// used by TextController to confirm a piece is being captured by a move so the visuals
// can be drawn accordingly (captured piece sent to middle of board, capturing piece replacing it in space)
bool VisualBoard::checkSpace(int row, int column) {
	if ((pieceLayout[row][column]) == 1 || (pieceLayout[row][column]) == 101) {
		return true;
	}
	else {
		return false;
	}
}